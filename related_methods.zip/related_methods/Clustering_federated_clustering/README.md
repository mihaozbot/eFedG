# Implementation of Federated Clustering algorithms

This repository contains implementations of federated clustering algorithms.

### Prerequisites

* python3
* Install packages in requirements.txt.
* Clone the repository https://github.com/stallmo/cluster_library.git and place on the same level as this one in your folder structure.
  * Install all packages required by the cluster library. 
  * TODO: Make this more convenient.