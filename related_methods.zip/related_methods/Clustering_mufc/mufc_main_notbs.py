import numpy as np
from sklearn.cluster import KMeans
from tqdm import tqdm
import copy
from kfed import kfed
from dc_kmeans import DCKmeans
from model import MyKmeans
from utils import load_dataset, clustering_loss, induced_loss, sample_points_in_bin

def run_federated_clustering(
    dataset,  # Provide the dataset directly
    num_clusters=10,
    num_clients=100,
    num_removes=10,
    client_oversample=1,
    k_prime=10,
    num_trials=1,
    max_iters=300,
    split='iid',
    compare_kfed=False,
    compare_dc=False,
    client_kpp_only=False,
    verbose=False,
    update_centralized_loss=False
):
    results = {
        "global_induced_loss": [],
        "local_induced_loss": [],
        "our_removal_time": [],
        "full_retrain_time": [],
        "num_retrain": [],
        "centralized_loss": [],
        "kfed_induced_loss": [],
        "kfed_time": [],
        "dc_induced_loss": [],
        "dc_removal_time": [],
        "final_clusters": []
    }

    n_init = 10
    quant_eps = 1 / np.sqrt(dataset["full_data"].shape[0])

    for i_trail in range(num_trials):
        global_induced_loss = np.zeros(num_removes + 1)
        local_induced_loss = np.zeros(num_removes + 1)
        our_removal_time = np.zeros(num_removes + 1)
        full_retrain_time = np.zeros(1)
        num_retrain = np.zeros(1)
        centralized_loss = np.ones(num_removes + 1)

        centralized_loss[0] = dataset["kmeans_loss"]
        client_worst_time_real = 0
        client_worst_time_baseline = 0
        kmeans_clients = []
        data_server = []

        for i_client in tqdm(range(num_clients)):
            start = time.time()
            if split == "iid":
                client_kmeans = MyKmeans(k=int(client_oversample * num_clusters), max_iters=max_iters)
            else:
                client_kmeans = MyKmeans(k=int(client_oversample * k_prime), max_iters=max_iters)

            if client_kpp_only:
                _, client_assignments, _ = client_kmeans.run_kpp_only(dataset["client_" + str(i_client)])
            else:
                _, client_assignments, _ = client_kmeans.run(dataset["client_" + str(i_client)])
            
            client_quant_centroids = client_kmeans.quantize_centroids(quant_eps)
            client_time_used = time.time() - start
            if client_time_used > client_worst_time_real:
                client_worst_time_real = client_time_used

            for i_client_n in range(client_kmeans.n):
                rnd_samples = sample_points_in_bin(client_quant_centroids[client_assignments[i_client_n]], 1, quant_eps)
                data_server.append(rnd_samples)

            client_dict = {"model": client_kmeans}
            kmeans_clients.append(client_dict)

            start = time.time()
            baseline_kmeans = MyKmeans(k=int(client_oversample * num_clusters), max_iters=max_iters)
            baseline_kmeans.run(dataset["client_" + str(i_client)])
            baseline_kmeans.quantize_centroids(quant_eps)
            baseline_time_used = time.time() - start
            if baseline_time_used > client_worst_time_baseline:
                client_worst_time_baseline = baseline_time_used

        start = time.time()
        data_server = np.concatenate(data_server, axis=0)
        assert data_server.shape[0] == dataset["full_data"].shape[0]

        kmeans_server = KMeans(n_clusters=num_clusters, max_iter=max_iters, n_init=n_init).fit(data_server)
        server_centroids, server_assignments = kmeans_server.cluster_centers_, kmeans_server.labels_

        our_removal_time[0] = time.time() - start + client_worst_time_real
        full_retrain_time[0] = time.time() - start + client_worst_time_baseline

        tmp_count = 0
        for i_client in range(num_clients):
            global_induced_loss[0] += clustering_loss(dataset["client_" + str(i_client)], server_centroids)
            local_induced_loss[0] += induced_loss(
                dataset["client_" + str(i_client)], server_centroids,
                server_assignments[tmp_count:tmp_count + dataset["client_" + str(i_client)].shape[0]]
            )
            tmp_count += dataset["client_" + str(i_client)].shape[0]

        if compare_kfed:
            kfed_data = [dataset["client_" + str(i_client)] for i_client in range(num_clients)]
            start = time.time()
            _, _, induced_kfed_loss = kfed(kfed_data, k_prime, num_clusters, max_iters=max_iters)
            kfed_time = time.time() - start
            results["kfed_induced_loss"].append(induced_kfed_loss)
            results["kfed_time"].append(kfed_time)

        if compare_dc:
            start = time.time()
            dckmeans = DCKmeans([num_clusters, k_prime], [1, num_clients], iters=max_iters, n_init=n_init)
            dc_dataset = copy.deepcopy(dataset)
            _, _, dc_induced_loss = dckmeans.run(dc_dataset)
            dc_removal_time = time.time() - start

            results["dc_induced_loss"].append(dc_induced_loss)
            results["dc_removal_time"].append(dc_removal_time)

        # Unlearning procedure
        data_combined = copy.deepcopy(dataset["full_data"])

        for i_remove in tqdm(range(num_removes)):
            client_idx_remove = np.random.randint(num_clients)
            while kmeans_clients[client_idx_remove]["model"].n < kmeans_clients[client_idx_remove]["model"].k:
                client_idx_remove = np.random.randint(num_clients)
            client_data_idx_remove = np.random.randint(kmeans_clients[client_idx_remove]["model"].n)

            client_kmeans = kmeans_clients[client_idx_remove]["model"]
            ori_data_server_size = data_server.shape[0]
            data_to_remove = client_kmeans.data[client_data_idx_remove]

            start = time.time()
            retrain_flag = client_kmeans.unlearn_check(client_data_idx_remove)

            if retrain_flag or not client_kpp_only:
                num_retrain[0] += 1
                tmp_data = np.delete(client_kmeans.data, client_data_idx_remove, axis=0)

                if split == "iid":
                    client_kmeans = MyKmeans(k=int(client_oversample * num_clusters), max_iters=max_iters)
                else:
                    client_kmeans = MyKmeans(k=int(client_oversample * k_prime), max_iters=max_iters)

                if client_kpp_only:
                    _, client_assignments, _ = client_kmeans.run_kpp_only(tmp_data)
                else:
                    _, client_assignments, _ = client_kmeans.run(tmp_data)

                client_quant_centroids = client_kmeans.quantize_centroids(quant_eps)

                data_server_remove_start = 0
                for before_client_idx_remove in range(client_idx_remove):
                    data_server_remove_start += kmeans_clients[before_client_idx_remove]["model"].n

                data_server_list = []
                if client_idx_remove != 0:
                    data_server_list.append(data_server[0:data_server_remove_start, :])

                for i_client_n in range(client_kmeans.n):
                    rnd_samples = sample_points_in_bin(client_quant_centroids[client_assignments[i_client_n]], 1, quant_eps)
                    data_server_list.append(rnd_samples)

                if client_idx_remove != num_clients - 1:
                    data_server_list.append(data_server[data_server_remove_start + tmp_data.shape[0] + 1:, :])

                data_server = np.concatenate(data_server_list, axis=0)

                kmeans_server = KMeans(n_clusters=num_clusters, max_iter=max_iters, n_init=n_init).fit(data_server)
                server_centroids, server_assignments = kmeans_server.cluster_centers_, kmeans_server.labels_
            else:
                data_server_remove_start = 0
                for before_client_idx_remove in range(client_idx_remove):
                    data_server_remove_start += kmeans_clients[before_client_idx_remove]["model"].n

                data_server = np.delete(data_server, data_server_remove_start + client_data_idx_remove, axis=0)
                server_assignments = np.delete(server_assignments, data_server_remove_start + client_data_idx_remove)

            our_removal_time[i_remove + 1] = time.time() - start
            kmeans_clients[client_idx_remove]["model"] = client_kmeans

            tmp_count = 0
            for i_client in range(num_clients):
                global_induced_loss[i_remove + 1] += clustering_loss(kmeans_clients[i_client]["model"].data, server_centroids)
                local_induced_loss[i_remove + 1] += induced_loss(
                    kmeans_clients[i_client]["model"].data, server_centroids,
                    server_assignments[tmp_count:tmp_count + kmeans_clients[i_client]["model"].data.shape[0]]
                )
                tmp_count += kmeans_clients[i_client]["model"].data.shape[0]

            global_remove_idx = np.where((data_combined == data_to_remove).all(axis=1))[0][0]
            data_combined = np.delete(data_combined, global_remove_idx, axis=0)

            if update_centralized_loss:
                clf = KMeans(n_clusters=num_clusters, max_iter=max_iters, n_init=n_init).fit(data_combined)
                centralized_loss[i_remove + 1] = clf.inertia_

            if verbose:
                print(
                    f"{i_remove+1}, number of retrain: {num_retrain[0]}, optimal loss: {centralized_loss[i_remove + 1]}; "
                    f"global induced: {global_induced_loss[i_remove + 1]}, ratio: {global_induced_loss[i_remove + 1] / centralized_loss[i_remove + 1]}; "
                    f"local induced: {local_induced_loss[i_remove + 1]}, ratio: {local_induced_loss[i_remove + 1] / centralized_loss[i_remove + 1]}"
                )
                print(
                    f"{i_remove+1}, time used: {our_removal_time[i_remove + 1]} s, ratio: {full_retrain_time[0] / our_removal_time[i_remove + 1]}"
                )

        results["global_induced_loss"].append(global_induced_loss)
        results["local_induced_loss"].append(local_induced_loss)
        results["our_removal_time"].append(our_removal_time)
        results["full_retrain_time"].append(full_retrain_time)
        results["num_retrain"].append(num_retrain)
        results["centralized_loss"].append(centralized_loss)
        results["final_clusters"].append(server_centroids)

    return results
