import numpy as np
from sklearn.cluster import KMeans
from tqdm import tqdm
from model_mufc import MyKmeans
from utils_mufc import clustering_loss, induced_loss, sample_points_in_bin
import numpy as np
from model_mufc import *
from utils_mufc import *
import time

def run_federated_clustering(dataset, num_clusters=10, num_clients=100, client_oversample=1, k_prime=10, max_iters=300, split='iid', client_kpp_only=False):
    """
    Runs the federated clustering process on the provided dataset and returns the relevant results.

    Parameters:
        dataset (dict): The dataset split among clients, containing 'full_data' and 'client_X' keys.
        num_clusters (int): Number of clusters for KMeans.
        num_clients (int): Number of clients/devices.
        client_oversample (int): Oversampling coefficient on client.
        k_prime (int): Real number of clusters on devices.
        max_iters (int): Maximum number of iterations for KMeans.
        split (str): 'iid' or 'non-iid' data split among clients.
        client_kpp_only (bool): Whether to only perform initialization on clients.

    Returns:
        dict: A dictionary containing the final clustering results, losses, and centroids.
    """

    # Compute quantization epsilon
    print("Use fixed eps")
    quant_eps = 1 / np.sqrt(dataset["full_data"].shape[0])
    print(f"eps = {quant_eps}, n = {dataset['full_data'].shape[0]}")

    # Initialize result storage
    global_induced_loss = 0
    local_induced_loss = 0
    full_retrain_time = 0
    centralized_loss = dataset["kmeans_loss"]  # Pre-computed optimal loss

    for i_trial in range(1):  # Assuming one trial since you removed unlearning and retrials
        print("=" * 30, f"Trial {i_trial}", "=" * 30)

        print("=" * 5, "MUFC training", "=" * 5)
        client_worst_time_real = 0
        kmeans_clients = []
        data_server = []

        for i_client in tqdm(range(num_clients)):
            # Client-side computation
            start = time.time()
            client_kmeans = MyKmeans(k=int(client_oversample * num_clusters), max_iters=max_iters) if split == 'iid' else MyKmeans(k=int(client_oversample * k_prime), max_iters=max_iters)

            if client_kpp_only:
                _, client_assignments, _ = client_kmeans.run_kpp_only(dataset[f"client_{i_client}"])
            else:
                _, client_assignments, _ = client_kmeans.run(dataset[f"client_{i_client}"])

            # Quantize centroids
            client_quant_centroids = client_kmeans.quantize_centroids(quant_eps)

            client_time_used = time.time() - start
            if client_time_used > client_worst_time_real:
                client_worst_time_real = client_time_used

            # Generate random samples within each quantization bin
            for i_client_n in range(client_kmeans.n):
                rnd_samples = sample_points_in_bin(client_quant_centroids[client_assignments[i_client_n]], 1, quant_eps)
                data_server.append(rnd_samples)

            # Store client information
            kmeans_clients.append({"model": client_kmeans})

        # Server-side computation
        start = time.time()
        data_server = np.concatenate(data_server, axis=0)
        assert data_server.shape[0] == dataset["full_data"].shape[0]

        # Run K-Means on the server
        kmeans_server = KMeans(n_clusters=num_clusters, max_iter=max_iters, n_init=10).fit(data_server)
        server_centroids, server_assignments = kmeans_server.cluster_centers_, kmeans_server.labels_

        full_retrain_time = time.time() - start + client_worst_time_real

        # Compute losses
        tmp_count = 0
        for i_client in range(num_clients):
            global_induced_loss += clustering_loss(dataset[f"client_{i_client}"], server_centroids)
            local_induced_loss += induced_loss(
                dataset[f"client_{i_client}"], server_centroids,
                server_assignments[tmp_count:tmp_count + dataset[f"client_{i_client}"].shape[0]]
            )
            tmp_count += dataset[f"client_{i_client}"].shape[0]

        print("=" * 5, "Loss after training", "=" * 5)
        print(f"mufc optimal loss: {centralized_loss}; global induced: {global_induced_loss}, ratio: {global_induced_loss / centralized_loss}; local induced: {local_induced_loss}, ratio: {local_induced_loss / centralized_loss}")
        print(f"mufc time used: {full_retrain_time} s")

    # Return results
    return {
        "global_induced_loss": global_induced_loss,
        "local_induced_loss": local_induced_loss,
        "full_retrain_time": full_retrain_time,
        "centralized_loss": centralized_loss,
        "final_clusters": server_centroids
    }


def federated_clustering_simple(dataset, num_clusters=10, num_clients=100, client_oversample=1, k_prime=10, max_iters=300, split='iid', client_kpp_only=True):
    """
    Runs a simplified federated clustering process on the provided dataset and returns the final clusters.

    Parameters:
        dataset (dict): The dataset split among clients, containing 'full_data' and 'client_X' keys.
        num_clusters (int): Number of clusters for KMeans.
        num_clients (int): Number of clients/devices.
        client_oversample (int): Oversampling coefficient on client.
        k_prime (int): Real number of clusters on devices.
        max_iters (int): Maximum number of iterations for KMeans.
        split (str): 'iid' or 'non-iid' data split among clients.
        client_kpp_only (bool): Whether to only perform initialization on clients.

    Returns:
        dict: A dictionary containing the final clustering centroids.
    """

    # Compute quantization epsilon
    print("Use fixed eps")
    quant_eps = 1 / np.sqrt(dataset["full_data"].shape[0])
    print(f"eps = {quant_eps}, n = {dataset['full_data'].shape[0]}")

    print("=" * 5, "MUFC training", "=" * 5)
    client_worst_time_real = 0
    data_server = []

    for i_client in tqdm(range(num_clients)):
        # Client-side computation
        start = time.time()
        client_kmeans = MyKmeans(k=int(client_oversample * num_clusters), max_iters=max_iters) if split == 'iid' else MyKmeans(k=int(client_oversample * k_prime), max_iters=max_iters)

        if client_kpp_only:
            _, client_assignments, _ = client_kmeans.run_kpp_only(dataset[f"client_{i_client}"])
        else:
            _, client_assignments, _ = client_kmeans.run(dataset[f"client_{i_client}"])

        # Quantize centroids
        client_quant_centroids = client_kmeans.quantize_centroids(quant_eps)

        client_time_used = time.time() - start
        if client_time_used > client_worst_time_real:
            client_worst_time_real = client_time_used

        # Generate random samples within each quantization bin
        for i_client_n in range(client_kmeans.n):
            rnd_samples = sample_points_in_bin(client_quant_centroids[client_assignments[i_client_n]], 1, quant_eps)
            data_server.append(rnd_samples)

    # Server-side computation
    start = time.time()
    data_server = np.concatenate(data_server, axis=0)
    assert data_server.shape[0] == dataset["full_data"].shape[0]

    # Run K-Means on the server
    kmeans_server = KMeans(n_clusters=num_clusters, max_iter=max_iters, n_init=10).fit(data_server)
    server_centroids = kmeans_server.cluster_centers_

    full_retrain_time = time.time() - start + client_worst_time_real

    print(f"mufc time used: {full_retrain_time} s")

    # Return final cluster centroids
    return {
        "final_clusters": server_centroids
    }
