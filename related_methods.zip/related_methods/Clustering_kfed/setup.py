from distutils.core import setup

setup(
    name='fkms',
    version='0.1',
    packages=['fkms']
)
