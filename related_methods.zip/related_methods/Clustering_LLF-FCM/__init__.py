#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Apr. 16 2:17 p.m. 2024

@author: José Luis Corcuera Bárcena
"""
